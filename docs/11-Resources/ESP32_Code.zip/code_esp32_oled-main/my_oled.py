from machine import Pin, I2C
import ssd1306
import time
from machine import UART
import uasyncio as asyncio

i2c = I2C(0, sda=Pin(41), scl=Pin(38), freq=100000)
oled = ssd1306.SSD1306_I2C(128, 64, i2c, addr=0x3C)

# To edit sending message, find "Find marker for sending"
########################################################

# these are to hold some/all the team member ids
team = [b'A',b'E',b'D',b'J',b'G',b'k,'b'Z']
# sender's id
id = b'A'
broadcast = b'X'
MAX_MESSAGE_LEN=64

# initialize a new UART class
uart = UART(2, 9600,tx=8,rx=18)
# run the init method with more details including baudrate and parity
uart.init(9600, bits=8, parity=None, stop=1) 
# define pin 2 as an output with name led. (Pin 2 is connected to the ESP32-WROOM dev board's onboard blue LED)
led = Pin(5,Pin.OUT)


def send_message(message):
    print('ESP: send message')
    # send_queue.append(message)

def handle_message(message):
    my_string = message.decode('utf-8')
    print('ESP: handling my message',message)
    


async def process_rx():

    # stream = []
    stream = b''
    message = b''
    send_queue = []
    receiving_message=False

    while True:
        # read one byte
        c = uart.read(1)
        # if c is not empty:
        if c is not None:

            stream+=c
            try:
                if stream[-2:]==b'AZ':
                    # print('ESP: message start:')
                    message=stream[-2:-1]
                    receiving_message=True
            except IndexError:
                pass
            try:
                if stream[-2:]==b'YB':
                    message+=stream[-1:]
                    stream=b''
                    receiving_message = False
                    # print('ESP: message received:',message)
                    handle_message(message)
                    led.value(led.value()^1)
            
            except IndexError:
                pass
            
            if receiving_message:
                
                message+=c

                if len(message)==3:
                    if not (message[2:3] in team):
                        print('ESP: sender not in team')
                    else:
                        print('ESP: sender IS in team')
                        if (message[4:5] == b's'):
                            uart.write(b'AZJEsYB')
                            print_text("Motor stop running", 0, 0)
                           
                        elif (message[4:5] == b'h'):
                            uart.write(b'AZJEhYB')
                            oled.text("Half-speed", 0, 0)
                            oled.show()
                           
                        elif (message[4:5] == b'f'):
                            uart.write(b'AZJEfYB')
                            oled.text("full speed", 0, 0)
                            oled.show()
                        
                        else:
                            print('ESP: sender in team-forward?')
                            print(message)
                           
                if len(message)==3:
                    if (message[2:3] in id):
                        print('ESP: sender was self')
                        
                if len(message)==4:
                    if (message[3:4] in broadcast):
                        print('ESP: received broadcast message')
                    
                if len(message)==5:
                    if not (message[3:4] in team):
                        print('ESP: receiver not in team')
                        oled.fill(0) #clear screen
                        oled.text("Not member", 0, 0)
                        oled.show()
                    else:
                        if (message[4:5] == b's'):
                            uart.write(b'AZJEsYB')
                            oled.fill(0) #clear screen
                            oled.text("Motor stop running", 0, 0)
                            oled.show()
                           
                        elif (message[4:5] == b'h'):
                            uart.write(b'AZJEhYB')
                            oled.fill(0) #clear screen
                            oled.text("Half-speed", 0, 0)
                            oled.show()
                           
                        elif (message[4:5] == b'f'):
                            uart.write(b'AZJEfYB')
                            oled.fill(0) #clear screen
                            oled.text("full speed", 0, 0)
                            oled.show()
                        
                        else:
                            print('ESP: reciever in team')
                            uart.write(b'AZJEfYB')
                            oled.fill(0) #clear screen
                            oled.text("not s-h-f", 0, 0)
                            oled.show()

                if len(message)>MAX_MESSAGE_LEN:
                    receiving_message = False
                    print('ESP: Message too long, aborting')
                    message=b''


        await asyncio.sleep_ms(10) 